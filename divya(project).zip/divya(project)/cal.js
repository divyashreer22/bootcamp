let inputField = document.getElementById("input-field");

function calculate() {
    let input = inputField.value;
    let result = eval(input);
    inputField.value = result;
}

function clearField() {
    inputField.value = "";
}

function add() {
    inputField.value += "+";
}

function subtract() {
    inputField.value += "-";
}

function multiply() {
    inputField.value += "*";
}

function divide() {
    inputField.value += "/";
}
