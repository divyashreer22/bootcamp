let train = document.querySelector('.train');
let carriages = document.querySelectorAll('.carriage');
let stations = document.querySelectorAll('.station');
let playButton = document.querySelector('#play-button');

// Add event listeners to carriages and stations
carriages.forEach((carriage, index) => {
    carriage.addEventListener('click', () => {
        // Simulate train movement
        train.style.transform = `translateX(${index * 20}%)`;
    });
});

stations.forEach((station, index) => {
    station.addEventListener('click', () => {
        // Simulate train arrival at station
        train.style.transform = `translateX(${index * 20}%)`;
    });
});

playButton.addEventListener('click', () => {
    // Simulate train movement
    train.style.transform = `translateX(${Math.random() * 100}%)`;
});

