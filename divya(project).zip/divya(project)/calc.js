let display = document.getElementById("display");

function append(number) {
    display.value += number;
}

function calculate() {
    let input = display.value;
    let result = eval(input);
    display.value = result;
}

function clearField() {
    display.value = "";
}
