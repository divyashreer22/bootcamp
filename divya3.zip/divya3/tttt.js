document.addEventListener('DOMContentLoaded',()=>{
   //loadPreference();
});
function savePreference(){
    const theme=document.getElementById('theme').value;
    const fontsize=document.getElementById('fontsize').value;
    localStorage.setItem('theme',theme);
    localStorage.setItem('fontsize',fontsize);

    alert('Perference saved');
    applyPerference();
}
function loadPerference(){
    const theme=localStroage.getItem('theme');
    const fontsize=localStroage.getItem('fontsize');

    if(theme){
        document.getElementById('theme').value=theme;

    }
    if(fontsize){
        document.getElementById('fontsize').value=fontsize;
}
applyPerference();
}
function applyPerference(){
    const theme=localStorage.getItem('theme');
    const fontsize=localStorage.getItem('fontsize');
     if(theme){
        document.body.className=theme;
     }
     if(fontsize){
        document.body.className=theme;
     }
     
    

    
}
